BLOB RUSH — GitHub Pages / PWA

Загрузите ВСЕ файлы из этой папки в корень GitHub-репозитория:
- index.html
- manifest.webmanifest
- service-worker.js
- icon-192.png
- icon-512.png

Затем откройте Settings → Pages, выберите Deploy from a branch, ветку main и папку /(root), нажмите Save.
После публикации откройте адрес GitHub Pages на телефоне и выберите «Добавить на главный экран» / «Установить приложение».

Важно: PWA-установка работает через HTTPS (GitHub Pages его предоставляет).
